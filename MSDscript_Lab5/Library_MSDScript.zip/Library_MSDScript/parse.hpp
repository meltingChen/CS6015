
#ifndef parse_hpp
#include "expr.hpp"
#define parse_hpp

#include <stdio.h>

#endif

Expr *parse_num(std::istream &in);
