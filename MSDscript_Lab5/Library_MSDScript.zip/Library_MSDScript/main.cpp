/**
* \mainpage MSDScript
* \author Tina Chen
* \date 07-02-2023
*/

#include <iostream>
#include <string>
#include "cmdline.hpp"
#include "expr.hpp"
#include "parse.hpp"

int main(int argc, const char * argv[]) {
//    // insert code here...
//    std::cout << (new Let("x", new Num(5), new Let("y", new Num(6), new Add(new Var("x"), new Num(1))))) ->to_pretty_string();
//    
//    use_arguments(argc, argv);
    return 0;
}
