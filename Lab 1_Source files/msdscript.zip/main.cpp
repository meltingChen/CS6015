//
//  main.cpp
//  MSDscript
//
//  Created by 陳肜樺 on 1/14/24.
//

#include <iostream>
#include <string>
#include "cmdline.hpp"

int main(int argc, const char * argv[]) {
    // insert code here...
    
//    std::cout << "Hello, World!\n";
//    use_arguments(argc, argv);
//    std::cerr << "Welcome to GfG! :: cerr\n";
//    std::string s;
//    std::cin >> s;
//    std::cout<<typeof(argv[1]);
    use_arguments(argc, argv);
    return 0;
}
