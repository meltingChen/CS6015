//
//  cmdline.cpp
//  MSDscript
//
//  Created by 陳肜樺 on 1/14/24.
//

#include "cmdline.hpp"
using namespace std;
void use_arguments(int argc,const char * argv[]){
    int testTracker = 0;
    for(int i =1 ;i<argc;i++){
        
        if(strcmp(argv[i],"--help")==0){
            cout<<"Available flags:"<<endl;
            cout<<"--test :run tests"<<endl;
            cout<<"--help : this help"<<endl;
            exit(0);
        }
        else if(strcmp(argv[i],"--test")==0){
            if(testTracker==0){
                cout<<"Tests passed!"<<endl;
                testTracker++;
            }
            else{
                cerr<<"Duplicate --test"<<endl;
                exit(1);
            }
            
        }
//        else if(strcmp(argv[1],"")==0){
//            return;
//        }
        else if(strcmp(argv[i],"")==0){
            continue;
        }
        else{
            cerr<<"bad flag"<<argv[i]<<", try another"<<endl;
            exit(1);
        }
        
    }
}
