//
//  cmdline.hpp
//  MSDscript
//
//  Created by 陳肜樺 on 1/14/24.
//

#ifndef cmdline_hpp
#define cmdline_hpp


#include <iostream>
#include <string>
#include <map>
#include <stdio.h>
#include <stdexcept>
#include "catch.h"



void use_arguments(int argc,const char * argv[]);

#endif /* cmdline_hpp */
