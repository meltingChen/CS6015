var searchData=
[
  ['subst_0',['subst',['../class_num.html#af55ca9043b01c85dc636a7efa13e0450',1,'Num::subst()'],['../class_add.html#a0149ec7316da26daf89f1c081b1ee821',1,'Add::subst()'],['../class_mult.html#acd883793e07c0e7e290dd7038d365c77',1,'Mult::subst()'],['../class_var.html#a4958915c8dcabb470425a5924639740a',1,'Var::subst()']]]
];
