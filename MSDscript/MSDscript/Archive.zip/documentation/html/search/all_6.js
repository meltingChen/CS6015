var searchData=
[
  ['name_0',['name',['../class_var.html#ad112053ba9381eb7b8b26b3c5702410a',1,'Var']]],
  ['num_1',['Num',['../class_num.html',1,'Num'],['../class_num.html#a9fce58e650a99ae50f4140ed9c87ec9f',1,'Num::Num()']]]
];
