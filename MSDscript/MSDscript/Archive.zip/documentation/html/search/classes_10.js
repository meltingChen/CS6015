var searchData=
[
  ['unaryexpr_0',['UnaryExpr',['../class_catch_1_1_unary_expr.html',1,'Catch']]],
  ['unorderedequalsmatcher_1',['UnorderedEqualsMatcher',['../struct_catch_1_1_matchers_1_1_vector_1_1_unordered_equals_matcher.html',1,'Catch::Matchers::Vector']]],
  ['usecolour_2',['UseColour',['../struct_catch_1_1_use_colour.html',1,'Catch']]]
];
