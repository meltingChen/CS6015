var searchData=
[
  ['pluralise_0',['pluralise',['../struct_catch_1_1pluralise.html',1,'Catch']]],
  ['predicatematcher_1',['PredicateMatcher',['../class_catch_1_1_matchers_1_1_generic_1_1_predicate_matcher.html',1,'Catch::Matchers::Generic']]],
  ['pretty_5fprint_2',['pretty_print',['../class_expr.html#a747e1f67ac65a4dd86458a03c9caa282',1,'Expr']]],
  ['pretty_5fprint_5fat_3',['pretty_print_at',['../class_num.html#a63135565df585c00b72f4a61f95ce118',1,'Num::pretty_print_at()'],['../class_add.html#a6fa0da9246bb28624d9468b751eb07f0',1,'Add::pretty_print_at()'],['../class_mult.html#a9541537914392cd40c0411b362418e42',1,'Mult::pretty_print_at()'],['../class_var.html#a171106ed9806796e4e7ea30f8ddd8ff7',1,'Var::pretty_print_at()']]],
  ['print_4',['print',['../class_num.html#a195a2a68e1cce0d0d691b419e63a82b2',1,'Num::print()'],['../class_add.html#aedb13df7dcefce72a82e918f314b7e5b',1,'Add::print()'],['../class_mult.html#ac8bd4c8166f6617a873f62f1788307f7',1,'Mult::print()'],['../class_var.html#af2ce14a46da46b94fed2d27d700cfa9d',1,'Var::print()']]]
];
